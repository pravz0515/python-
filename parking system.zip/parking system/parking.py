from datetime import datetime

# parking slots
slots = {1: None,2: None,3: None,4: None,5: None}
def park_vehicle():
    print(" Park Vehicle ")
    vehicle_no = input("Enter vehicle number: ")
    name = input("Enter owner name: ")
    vehicle_type = input("Enter vehicle type (car/bike): ")
# checking whether vehicle is already parked
    for slot in slots:
        if slots[slot] is not None:
            if slots[slot]["vehicle_no"] == vehicle_no:
                print("Vehicle is already parked.")
                return
# To find empty slot
    for slot in slots:
        if slots[slot] is None:
            slots[slot] = {
                "vehicle_no": vehicle_no,
                "name": name,
                "type": vehicle_type,
                "entry_time": datetime.now()
            }

            print("Vehicle parked successfully.")
            print("Your parking slot is:", slot)
            return

    print("Parking is full.")


def remove_vehicle():
    print("Remove Vehicle")

    vehicle_no = input("Enter vehicle number: ")

    for slot in slots:

        if slots[slot] is not None:

            if slots[slot]["vehicle_no"] == vehicle_no:

                vehicle = slots[slot]

                exit_time = datetime.now()
                entry_time = vehicle["entry_time"]

                time = exit_time - entry_time
                hours = time.total_seconds() / 3600

                # minimum one hour charge
                if hours < 1:
                    hours = 1
                else:
                    hours = int(hours) + 1

                if vehicle["type"].lower() == "bike":
                    amount = hours * 20
                else:
                    amount = hours * 40

                print("Parking Bill")
                print("Vehicle Number:", vehicle["vehicle_no"])
                print("Owner Name:", vehicle["name"])
                print("Vehicle Type:", vehicle["type"])
                print("Parking Slot:", slot)
                print("Entry Time:", entry_time)
                print("Exit Time:", exit_time)
                print("Parking Hours:", hours)
                print("Total Amount: Rs.", amount)

                slots[slot] = None

                print("Vehicle removed successfully.")
                return

    print("Vehicle not found.")


def show_slots():
    print("Parking Slots")

    for slot in slots:

        if slots[slot] is None:
            print("Slot", slot, ": Available")
        else:
            print(
                "Slot", slot, ":",
                slots[slot]["vehicle_no"],
                "-", slots[slot]["type"]
            )


def search_vehicle():
    print("Search Vehicle")

    vehicle_no = input("Enter vehicle number: ")

    for slot in slots:

        if slots[slot] is not None:

            if slots[slot]["vehicle_no"] == vehicle_no:

                print("\nVehicle Found")
                print("Parking Slot:", slot)
                print("Vehicle Number:", slots[slot]["vehicle_no"])
                print("Owner Name:", slots[slot]["name"])
                print("Vehicle Type:", slots[slot]["type"])
                print("Entry Time:", slots[slot]["entry_time"])

                return

    print("Vehicle not found.")


while True:

    
    print("PARKING MANAGEMENT SYSTEM")
    print("1. Park Vehicle")
    print("2. Remove Vehicle")
    print("3. Show Parking Slots")
    print("4. Search Vehicle")
    print("5. Exit")
    choice = input("Enter your choice: ")

    if choice == "1":
        park_vehicle()

    elif choice == "2":
        remove_vehicle()

    elif choice == "3":
        show_slots()

    elif choice == "4":
        search_vehicle()

    elif choice == "5":
        print("Thank you for using the parking system.")
        break

    else:
        print("Invalid choice. Please enter 1 to 5.")